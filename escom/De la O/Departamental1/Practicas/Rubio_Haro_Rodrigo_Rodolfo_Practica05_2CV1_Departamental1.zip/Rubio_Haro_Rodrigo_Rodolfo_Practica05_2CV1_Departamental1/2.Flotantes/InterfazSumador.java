class InterfazSumador {

    public static void main(String args[]) {
        SumadorFlotantes menu = new SumadorFlotantes();
        menu.sumarFlotantes();
        menu.imprimirRespuesta();
    }
}