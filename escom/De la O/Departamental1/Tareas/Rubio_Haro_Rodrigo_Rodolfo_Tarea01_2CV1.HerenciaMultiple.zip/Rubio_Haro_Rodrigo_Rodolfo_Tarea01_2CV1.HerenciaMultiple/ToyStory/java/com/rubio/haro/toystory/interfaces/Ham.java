package com.rubio.haro.toystory.interfaces;

public interface Ham extends Alcancia, DoctorTocino, Cerdo{
    public void manejar();
}