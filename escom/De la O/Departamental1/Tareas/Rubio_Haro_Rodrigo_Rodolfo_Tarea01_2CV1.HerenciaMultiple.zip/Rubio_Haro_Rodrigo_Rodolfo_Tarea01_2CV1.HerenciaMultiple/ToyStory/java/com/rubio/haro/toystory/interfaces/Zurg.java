package com.rubio.haro.toystory.interfaces;

public interface Zurg extends Juguete {

    public void lanzarPelota();
}
