
public class TiposDeDatos {
    public static void main(String[] args) {
        Datos lista = new Datos();
        lista.imprimirDatos();
    }
}