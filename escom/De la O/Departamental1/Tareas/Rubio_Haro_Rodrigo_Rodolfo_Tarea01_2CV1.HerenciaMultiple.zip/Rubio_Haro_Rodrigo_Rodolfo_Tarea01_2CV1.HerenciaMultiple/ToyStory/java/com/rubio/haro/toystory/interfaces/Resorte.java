package com.rubio.haro.toystory.interfaces;
public interface Resorte {
    public void estirar();
}