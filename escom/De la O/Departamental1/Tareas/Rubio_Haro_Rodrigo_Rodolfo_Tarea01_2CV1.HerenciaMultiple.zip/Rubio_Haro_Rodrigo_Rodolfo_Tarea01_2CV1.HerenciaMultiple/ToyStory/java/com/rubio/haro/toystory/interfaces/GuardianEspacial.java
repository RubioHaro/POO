package com.rubio.haro.toystory.interfaces;
public interface GuardianEspacial {
    public void protegerGalaxia();
}