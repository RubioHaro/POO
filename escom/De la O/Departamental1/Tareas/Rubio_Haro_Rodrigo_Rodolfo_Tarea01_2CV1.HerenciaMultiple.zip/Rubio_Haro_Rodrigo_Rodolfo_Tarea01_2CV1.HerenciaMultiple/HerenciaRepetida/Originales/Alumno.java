public interface Alumno extends Persona {
}