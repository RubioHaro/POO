public class InterfazConversiones {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.imprimirMenu();
    }

}