/**
 * pitido
 */
public class Pitido {

    private final String secuenciaEscape = "\007";

    @Override
    public String toString() {
        return secuenciaEscape;
    }

}