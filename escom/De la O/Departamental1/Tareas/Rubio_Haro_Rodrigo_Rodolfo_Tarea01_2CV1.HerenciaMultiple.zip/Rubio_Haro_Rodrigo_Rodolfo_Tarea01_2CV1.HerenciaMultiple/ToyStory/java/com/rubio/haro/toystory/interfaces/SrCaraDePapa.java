package com.rubio.haro.toystory.interfaces;

/**
 * SrCaraDePapa
 */
public interface SrCaraDePapa extends Papa, Esposo, Padre, Juguete, Tortilla, Pepino {

    public void enojar();
}