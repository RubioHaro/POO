package com.rubio.haro.toystory.interfaces;
public interface Slinky extends Resorte, Perro, Juguete{
    public void animar();
}