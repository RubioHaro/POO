
public class TiposDeDatos {
    public static void main(String[] args) {
        ListaTiposDatos lista = new ListaTiposDatos();
        lista.imprimirDatos();
    }
}