package com.rubio.haro.toystory.interfaces;
public interface Papa {
    public void germinar();
}