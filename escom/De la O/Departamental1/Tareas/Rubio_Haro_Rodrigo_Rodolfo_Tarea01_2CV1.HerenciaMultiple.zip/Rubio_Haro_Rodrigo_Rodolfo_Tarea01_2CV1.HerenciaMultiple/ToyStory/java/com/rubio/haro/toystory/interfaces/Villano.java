package com.rubio.haro.toystory.interfaces;
public interface Villano {
    public void traicionar(Heroe heroe);
}