package com.rubio.haro.toystory.interfaces;
public interface DoctorTocino extends Villano{
    public void robar();
}