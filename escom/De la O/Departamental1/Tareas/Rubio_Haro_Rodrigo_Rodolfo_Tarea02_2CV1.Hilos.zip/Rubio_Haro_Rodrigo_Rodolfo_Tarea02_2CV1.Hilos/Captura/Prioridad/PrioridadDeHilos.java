
package Prioridad;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class PrioridadDeHilos {

    public static void main(String[] args) {
        new PrioridadHilos().probar();
    }
}
