public interface Trabajador {
    public double SALARIO_BASE = 4000.0;

    public void trabajar();

    public double cobrar();
}