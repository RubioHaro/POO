package com.rubio.haro.toystory.interfaces;
public interface Depredador {
    public void cazar();
}