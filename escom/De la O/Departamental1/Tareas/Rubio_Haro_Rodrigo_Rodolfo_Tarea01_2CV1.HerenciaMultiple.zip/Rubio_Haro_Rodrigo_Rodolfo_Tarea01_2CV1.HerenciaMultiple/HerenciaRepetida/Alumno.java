
public interface Alumno extends Persona {
    public void estudiar();
}
