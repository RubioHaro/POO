package com.rubio.haro.toystory.interfaces;
public interface Oso {
    public void comer();
}