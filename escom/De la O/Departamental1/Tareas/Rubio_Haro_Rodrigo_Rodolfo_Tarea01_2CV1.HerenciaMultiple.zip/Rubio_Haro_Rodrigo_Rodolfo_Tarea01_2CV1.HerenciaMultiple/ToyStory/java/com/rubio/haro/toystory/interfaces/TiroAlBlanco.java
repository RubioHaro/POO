package com.rubio.haro.toystory.interfaces;
public interface TiroAlBlanco extends Caballo, Juguete{
    public void correrComoElViento();
}