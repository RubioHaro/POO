package com.rubio.haro.toystory.interfaces;
public interface Esposo {
    public void proveer();
}