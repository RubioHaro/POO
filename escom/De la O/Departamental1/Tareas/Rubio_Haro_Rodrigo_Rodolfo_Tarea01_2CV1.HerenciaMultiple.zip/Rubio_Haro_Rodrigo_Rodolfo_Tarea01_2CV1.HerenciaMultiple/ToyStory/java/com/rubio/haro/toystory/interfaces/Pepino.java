package com.rubio.haro.toystory.interfaces;
public interface Pepino {
    public void estarSaludable();
}