package com.rubio.haro.toystory.interfaces;
public interface Caballo {
    public void relinchar();
}