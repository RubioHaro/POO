public class Becario implements Trabajador, Alumno {
    
}