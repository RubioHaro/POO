package Marquee;

import javax.swing.JFrame;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class GeneradorMarquesita {
    
    public static void main(String[] args) {
        new FrameMarquee().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
