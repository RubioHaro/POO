package com.rubio.haro.toystory.interfaces;
public interface Juguete {
    public void jugar();
}