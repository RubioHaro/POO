package com.rubio.haro.toystory.interfaces;
public interface Woody extends Heroe, Vaquero, AmigoFiel {
    public void cuidar(Heroe heroe);
    public void cuidar(Villano villano);
}