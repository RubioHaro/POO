
/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ProbadorDeHerencia {
    public static void main(String[] args) {
        new HerenciaMultiple().probarHerencia();
    }
}
