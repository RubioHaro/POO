package com.rubio.haro.toystory.interfaces;
public interface Oloroso {
    public void oler();
}