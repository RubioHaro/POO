package com.rubio.haro.toystory.interfaces;
public interface Peluche {
    public void regalar();
}