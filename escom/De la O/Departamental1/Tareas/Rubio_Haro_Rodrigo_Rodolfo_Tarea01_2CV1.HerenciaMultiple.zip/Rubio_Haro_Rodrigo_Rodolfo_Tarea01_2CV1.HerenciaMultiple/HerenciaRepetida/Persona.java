
public interface Persona extends SerHumano {

    public void comer(String comida, String donde);

    public void hablar(String blabla);
    public String getNombre();
}
