package com.rubio.haro.toystory.interfaces;
public interface Cerdo {
    public void revolcar();
}