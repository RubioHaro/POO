package com.rubio.haro.toystory.interfaces;
public interface Padre {
    public void cuidar();
}