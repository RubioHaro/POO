package Sincronizacion.Bloqueos;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ProbadorCandado {

    public static void main(String[] args) {
        new DeadLock();
    }
}
