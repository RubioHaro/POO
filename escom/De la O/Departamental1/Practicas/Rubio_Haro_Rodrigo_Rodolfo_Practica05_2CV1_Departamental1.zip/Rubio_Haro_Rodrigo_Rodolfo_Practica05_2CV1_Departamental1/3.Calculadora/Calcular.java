public class Calcular {
    public static void main(String[] args) {
        Calculadora calcu = new Calculadora();
        calcu.DesplegarMenu();
        // System.out.println((-64)>>1); ES igual a -32
    }
}