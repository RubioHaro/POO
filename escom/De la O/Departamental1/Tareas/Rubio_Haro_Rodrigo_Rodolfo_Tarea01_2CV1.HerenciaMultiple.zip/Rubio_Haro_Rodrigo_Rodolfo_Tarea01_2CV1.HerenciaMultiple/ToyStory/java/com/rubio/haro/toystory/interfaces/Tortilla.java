package com.rubio.haro.toystory.interfaces;
public interface Tortilla {
    public void romper();
}