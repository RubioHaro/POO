package com.rubio.haro.toystory.interfaces;
public interface Perro {
    public void ladrar();
}