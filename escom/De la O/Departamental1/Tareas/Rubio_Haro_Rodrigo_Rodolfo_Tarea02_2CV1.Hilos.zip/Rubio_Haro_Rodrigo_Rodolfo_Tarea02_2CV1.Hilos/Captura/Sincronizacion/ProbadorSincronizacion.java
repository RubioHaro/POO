package Sincronizacion;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ProbadorSincronizacion {

    public static void main(String[] args) {
        new SincronizaHilos().probar();
    }
}
