package com.rubio.haro.toystory.interfaces;
public interface Vaquero {
    public void montar(TiroAlBlanco tiro);
}