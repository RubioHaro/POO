package com.rubio.haro.toystory.interfaces;
public interface Jessie extends Vaquero, Juguete , Heroe{
    public void cantar();
    public void cabalgar();
    public void tenerMiedo();
}