package com.rubio.haro.toystory.interfaces;
public interface Alcancia {
    public void guardarDinero();
}