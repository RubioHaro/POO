package com.rubio.haro.toystory.interfaces;
public interface AmigoFiel {
    public void apoyar(Juguete jugete);
    public void apoyar(Heroe heroe);
}