package com.rubio.haro.toystory.interfaces;

public interface JugadorVideoJuego {
    public void juego();
}