package com.rubio.haro.toystory.interfaces;
/**
 * Heroe
 */
public interface Heroe {
    public void salvar(Juguete jueguete);
}