package CaritaConHilo;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class GeneradorCarita {

    public static void main(String[] args) {
        FrameCarita frameCarita = new FrameCarita();
    }
}
