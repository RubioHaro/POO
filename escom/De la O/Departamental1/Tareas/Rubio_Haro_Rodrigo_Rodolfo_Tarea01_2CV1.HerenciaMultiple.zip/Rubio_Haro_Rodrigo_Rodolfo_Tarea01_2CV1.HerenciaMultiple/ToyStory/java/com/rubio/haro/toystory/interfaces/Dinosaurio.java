package com.rubio.haro.toystory.interfaces;
public interface Dinosaurio extends Depredador{
    public void rugir();
}