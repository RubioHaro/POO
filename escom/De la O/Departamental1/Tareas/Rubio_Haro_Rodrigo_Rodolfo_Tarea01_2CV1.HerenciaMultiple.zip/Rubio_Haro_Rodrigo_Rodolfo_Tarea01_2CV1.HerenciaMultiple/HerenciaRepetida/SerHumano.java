
/**
 *
 * @author Saul Torres de la O (sdelaot)
 * @author Rodrigo R. Rubio Haro (roy). Adaptaciones menores
 * @version 2.0
 */
public interface SerHumano {
    public void comer();
}
