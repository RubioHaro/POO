
package AliveAndJoin;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ProbadorJoin {

    public static void main(String[] args) {
        new HilosJoin().probar();
    }
}
