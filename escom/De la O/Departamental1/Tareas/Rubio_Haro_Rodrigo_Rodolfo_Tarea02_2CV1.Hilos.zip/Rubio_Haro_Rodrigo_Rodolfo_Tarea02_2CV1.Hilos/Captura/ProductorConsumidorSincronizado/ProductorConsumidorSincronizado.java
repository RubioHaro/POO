package ProductorConsumidorSincronizado;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ProductorConsumidorSincronizado {

    public static void main(String[] args) {
       new ProcesoConsumo().iniciar();
    }
}
