package com.rubio.haro.toystory.interfaces;
public interface BuzzLigthYear extends Heroe, GuardianEspacial, Zurg{
    public void volar();
    public void caerConEstilo();
}