package com.rubio.haro.toystory.interfaces;
public interface Rex extends Dinosaurio, Juguete, JugadorVideoJuego{
    public void derrotar(Villano villano);
}