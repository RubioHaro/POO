package com.rubio.haro.toystory.interfaces;
public interface Lotso extends Peluche, Oso, Oloroso, Villano{
    public void defraudar();
}