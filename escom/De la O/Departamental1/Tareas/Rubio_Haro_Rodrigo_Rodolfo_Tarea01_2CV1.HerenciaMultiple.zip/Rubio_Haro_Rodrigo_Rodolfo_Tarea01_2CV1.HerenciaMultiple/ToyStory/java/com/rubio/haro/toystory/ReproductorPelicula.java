package com.rubio.haro.toystory;

/**
 *
 * @author Rubio Haro Rodrigo R.
 */
public class ReproductorPelicula {

    public static void main(String[] args) {
        new Pelicula().reproducirPelicula();
    }
}
